<?php return [
    'plugin' => [
        'name' => 'Translater',
        'description' => 'String Key Based Translater'
    ]
];