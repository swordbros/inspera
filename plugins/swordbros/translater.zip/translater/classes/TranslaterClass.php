<?php namespace Swordbros\Translater\Classes;

use Backend;
use BackendMenu;
use Backend\Classes\Controller;

class TranslaterClass extends Translator
{

}

