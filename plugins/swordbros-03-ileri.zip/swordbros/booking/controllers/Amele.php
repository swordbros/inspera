<?php namespace Swordbros\Booking\Controllers;

use Backend\Classes\Controller;
use Backend\Controllers\Index\DashboardHandler;
use BackendMenu;
use October\Rain\Support\Facades\Schema;
use Site;
use Swordbros\Booking\models\EventCategoryModel;
use Swordbros\Booking\Models\EventModel;
use Swordbros\Booking\models\EventTypeModel;
use Swordbros\Booking\models\EventZoneModel;
use Swordbros\Booking\Models\Message;
use Swordbros\Event\Models\EventTranslateModel;
use Swordbros\Event\Models\TypeModel;
use Swordbros\Event\Models\ZoneModel;

class Amele extends Controller
{
    public static function test(){
        echo 'Test Language: '.__('Test Language');
    }
}

