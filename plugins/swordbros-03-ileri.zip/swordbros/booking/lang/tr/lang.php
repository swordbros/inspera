<?php return [
    'plugin' => [
        'name' => 'Swordbros Rezervasyonlar',
        'description' => 'Swordbros Rezervasyon Eklentisi',
        'title' => 'Rezervasyonlar',
        'calendar' => 'Takvim',
        'bookings' => 'Rezervasyonlar',
        'bookingcreate' => 'Rezervasyon Oluştur',
        'requests' => 'Rezervasyonlar Talepleri',
        'zones' => 'Alanlar',
        'types' => 'Rezervasyon Türleri',
        'categories' => 'Kategoriler',
        'group_key' => 'Grup Keyi',
        'booking_zone' => 'Rezervasyon Alanı',
        'booking_category' => 'Etkinilik Kategorisi',
        'booking_type' => 'Rezervasyon Türü',
        'status' => 'Durumu',
    ],
];
