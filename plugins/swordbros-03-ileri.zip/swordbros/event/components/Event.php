<?php namespace Swordbros\Event\Components;

use Media\Classes\MediaLibrary;
use Swordbros\Event\Controllers\Amele;
use Swordbros\Event\Models\EventModel;
use System;
use Backend;
use Cms\Classes\ComponentBase;

/**
 * BackendLink component
 */
class Event extends ComponentBase
{
    public function componentDetails()
    {
        return [
            'name' => 'Last Events',
            'description' => 'Show Last Events.'
        ];
    }

    public function onRun()
    {
        $this->page['mediaUrl'] = MediaLibrary::url('/');
        $this->page['title'] = __('swordbros.event::lang.plugin.events');
        $this->page['events'] = EventModel::all();
    }
}
