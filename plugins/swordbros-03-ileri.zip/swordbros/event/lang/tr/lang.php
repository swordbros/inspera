<?php return [
    'plugin' => [
        'name' => 'Swordbros Etkinlikler',
        'description' => 'Swordbros Etkinlik Eklentisi',
        'title' => 'Etkinlikler',
        'calendar' => 'Takvim',
        'events' => 'Etkinlikler',
        'zones' => 'Alanlar',
        'types' => 'Etkinlik Türleri',
        'categories' => 'Kategoriler',
        'group_key' => 'Grup Keyi',
        'event_zone' => 'Etkinlik Alanı',
        'event_category' => 'Etkinilik Kategorisi',
        'event_type' => 'Etkinlik Türü',
        'status' => 'Durumu',
    ],
];
