<?php return [
    'plugin' => [
        'name' => 'Swordbros Event',
        'description' => 'Swordbros Event Plugin',
        'title' => 'Events',
        'calendar' => 'Calender',
        'events' => 'Events',
        'zones' => 'Zones',
        'types' => 'Event Types',
        'categories' => 'Categories',
        'group_key' => 'Grup Key',
        'event_zone' => 'Event Zone',
        'event_category' => 'Event Category',
        'event_type' => 'Event Type',
        'status' => 'Status',
    ]
];
