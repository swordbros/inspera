<?php namespace Swordbros\Event\Controllers;

use Backend\Classes\Controller;
use Backend\Controllers\Index\DashboardHandler;
use BackendMenu;
use October\Rain\Support\Facades\Schema;
use Site;
use Swordbros\Booking\models\EventCategoryModel;
use Swordbros\Booking\Models\EventModel;
use Swordbros\Booking\models\EventTypeModel;
use Swordbros\Booking\models\EventZoneModel;
use Swordbros\Booking\Models\Message;
use Swordbros\Event\Models\EventTranslateModel;
use Swordbros\Event\Models\TypeModel;
use Swordbros\Event\Models\ZoneModel;

class Amele extends Controller
{
    public static function test(){
        echo 'Test Language: '.__('Test Language');
    }
    public static function localize_row($row){
        $plugin = $row->table;
        $record_id = $row->id;
        foreach($row->attributes as $translate_key=>$attribute_value){
            $text = "$plugin.$translate_key.$record_id";
            $translated = self::translate($text);
            if($translated){
                $row->$translate_key = $translated;
            }
        }
        return $row;
    }
    public static function save_localize_row($row){
        $plugin = $row->table;
        $record_id = $row->id;
        $site_id = Site::getSiteIdFromContext();
        foreach($row->attributes as $translate_key=>$attribute_value){
            if(self::is_translatable($translate_key)){
                $query = EventTranslateModel::where([['plugin','=', $plugin], ['translate_key','=', $translate_key], ['record_id','=', $record_id], ['site_id','=', $site_id]]);
                $translate = $query->first();
                if(empty($translate)){
                    $translate = new EventTranslateModel();
                    $translate->plugin = $plugin;
                    $translate->translate_key = $translate_key;
                    $translate->record_id = $record_id;
                    $translate->site_id = $site_id;
                }
                $translate->translate_value = $attribute_value;
                $translate->save();
            }
        }
    }
    private static function is_translatable($translate_key){
        /*if(is_object($value)){
            return false;
        }
        if(is_array($value)){
            return false;
        }
        if(is_numeric($value)){
            return false;
        }
        if (strtotime($value)) {
            return false;
        }
        if (\DateTime::createFromFormat('Y-m-d H:i:s', $value) !== false) {
            return false;
        }*/
        if(is_string($translate_key)){
            $translatable = ['name', 'title', 'description', 'short'];
            if(in_array($translate_key, $translatable)){
                return true;
            }
        }
        return false;
    }

    public static function _e($key){
        echo self::translate($key);
    }
    public static function translate($key){
        $parts = explode('.', $key);
        $plugin = isset($parts[0])?$parts[0]:'';
        $translate_key   = isset($parts[1])?$parts[1]:'';
        $record_id  = isset($parts[2])?(int)$parts[2]:0;
        $site_id = Site::getSiteIdFromContext();
        $query = EventTranslateModel::where([['plugin','=', $plugin], ['translate_key','=', $translate_key], ['record_id','=', $record_id], ['site_id','=', $site_id]]);
        $row = $query->first();
        if($row){
            return $row->translate_value;
        }
        return '';

    }
    public static function services(){
        $result = [];
        foreach (TypeModel::all() as $item) {
            $result[$item->id] = $item;
        }
        return $result;
    }
    public static function places(){
        $result = [];
        foreach (ZoneModel::all() as $item) {
            $result[$item->id] = $item;
        }
        return $result;
    }

    public function dummyData(){
       foreach (Amele::eventTypes() as $code=>$name){
            $item = new TypeModel();
            $item->name = $name;
            $item->description = $name.' Description';
            $item->save();
        }
        foreach (Amele::eventZones() as $code=>$name){
            $item = new ZoneModel();
            $item->name = $name;
            $item->description = $name.' Description';
            $item->save();
        }
        foreach (Amele::eventCategories() as $code=>$name){
            $item = new CategoryModel();
            $item->name = $name;
            $item->description = $name.' Description';
            $item->save();
        }
        $item = new EventModel();
        $item->event_zone_id = 1;
        $item->event_category_id = 1;
        $item->event_type_id = 1;
        $item->save();

    }
    public static function eventTypes(){
        return [
            'concert' =>  __('Concerts'),
            'theater' => __('Theater'),
            'cinema' =>  __('Cinema'),
            'workshop' => __('Workshop'),
            'exhibition' => __('Exhibition'),
        ];
    }
    public static function eventZones(){
        return [
            'zone001' =>  __('Küçük Sahne'),
            'zone002' => __('Büyük Sahne'),
            'zone003' =>  __('Atolye'),
        ];
    }
    public static function eventCategories(){
        return [
            'caz' =>  __('Caz'),
            'drama' => __('Drama'),
            'action' =>  __('Aksiyon'),
        ];
    }


}

class Service{
    public $code ;
    public $title ;
    public $icon ;
    public $url ;
    public static function create($code, $title='', $icon='', $url=''){
        $service = new Service();
        $service->code = $code;
        $service->title = $title;
        $service->icon = $icon;
        $service->url = $url;
        return $service;
    }
}
class Place{
    public $code ;
    public $title ;
    public $icon ;
    public $url ;
    public static function create($code, $title='', $icon='', $url=''){
        $service = new Place();
        $service->code = $code;
        $service->title = $title;
        $service->icon = $icon;
        $service->url = $url;
        return $service;
    }
}
