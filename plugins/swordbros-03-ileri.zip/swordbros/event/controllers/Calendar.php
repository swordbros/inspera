<?php namespace Swordbros\Event\Controllers;

use Backend;
use Backend\Classes\FormField;
use Backend\FormWidgets\RichEditor;
use BackendMenu;
use Backend\Classes\Controller;
use RainLab\Builder\FormWidgets\FormBuilder;
use Swordbros\Event\Models\EventModel;


class Calendar extends Controller
{
    public $implement = [
        \Backend\Behaviors\FormController::class,
        \Backend\Behaviors\ListController::class
    ];

    public $formConfig = 'config_form.yaml';
    public $listConfig = 'config_list.yaml';
    public $requiredCss = [
        '/plugins/swordbros/event/assets/css/swordbros.event.main.css',
    ];
    public $requiredJs = [
        '/plugins/swordbros/event/assets/js/swordbros.event.main.js',
        '/plugins/swordbros/event/assets/fullcalendar/index.global.js'
    ];

    public function __construct()
    {

        parent::__construct();
        BackendMenu::setContext('Swordbros.Event', 'main-menu-item', 'side-menu-item');
    }
    public function index(){
        $this->vars['services'] = Amele::services();
        $this->vars['places'] = Amele::places();
        $this->vars['events'] = $this->eventsToCalender();
        $this->formConfig = $this->makeConfig('$/swordbros/event/models/eventmodel/fields.yaml');
        $this->asExtension('FormController')->create();

    }
    private function eventsToCalender(){
        $rows = EventModel::all();
        $events = [];
        if(!$rows->isEmpty()){
            foreach ($rows as $row){
                $events[] = [
                    'title'=>$row->title,
                    'start'=>$row->start,
                    'end'=>$row->end,
                    'borderColor'=>$row->color,
                    /*'backgroundColor'=>$row->color,
                    'borderColor'=>$row->color,
                    'textColor'=>$row->color,*/
                ];
            }
        }
        return json_encode($events, JSON_UNESCAPED_UNICODE);
    }
    public function beforeDisplay()
    {
        $this->loadAssets();
    }
    private function loadAssets(){

        foreach($this->requiredJs as $requiredJs){
            $this->addJs($requiredJs);
        }
        foreach($this->requiredCss as $requiredCss){
            $this->addCss($requiredCss);
        }
    }
    public function onGetEventTypeForm()
    {
        $content = Event::emptyForm();

        return ['#listBulkActions' => $content];
    }
}
