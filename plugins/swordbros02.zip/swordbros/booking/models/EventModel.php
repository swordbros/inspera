<?php
namespace Swordbros\Booking\Models;

use Backend\Models\UserGroup;
use Backend\Models\UserRole;
use Model;
use Swordbros\Booking\Controllers\Helper;

class EventModel extends Model
{
    protected $table = 'swordbros_events';
    public function getEventCategoryIdOptions(){
        $result = [];
        foreach (EventCategoryModel::all() as $item) {
            $result[$item->id] = [$item->name, $item->description];
        }
        return $result;
    }
    public function getEventTypeIdOptions(){
        $result = [];
        foreach (EventTypeModel::all() as $item) {
            $result[$item->id] = [$item->name, $item->description];
        }
        return $result;
    }
    public function getEventZoneIdOptions(){
        $result = [];
        foreach (EventZoneModel::all() as $item) {
            $result[$item->id] = [$item->name, $item->description];
        }
        return $result;
    }
}
