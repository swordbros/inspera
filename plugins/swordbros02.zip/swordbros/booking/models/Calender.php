<?php
namespace Swordbros\Booking\models;

use Backend\Models\UserGroup;
use Backend\Models\UserRole;
use Model;
use Swordbros\Booking\Controllers\Helper;

class Calender extends Model
{
    protected $table = 'swordbros_events';
    public $attachOne = [
        'avatar' => \System\Models\File::class
    ];

    public function getRoleOptions()
    {
        $result = [];
        foreach (UserRole::all() as $role) {
            $result[$role->id] = [$role->name, $role->description];
        }
        return $result;
    }
    public function getSubscriptionOptions(){
        return Helper::subscriptions();
    }
    public function listGetConfig($definition)
    {
        $config = $this->asExtension('ListController')->listGetConfig($definition);

        // Implement structure dynamically
        $config->structure = [
            'showTree' => true
        ];

        return $config;
    }
}
