<?php
namespace Swordbros\Booking\models;

use Backend\Models\UserGroup;
use Backend\Models\UserRole;
use Model;
use Swordbros\Booking\Controllers\Helper;

class EventZoneModel extends Model
{
    protected $table = 'swordbros_event_zones';
}
