<?php namespace Swordbros\Booking\Controllers;

use Backend\Classes\Controller;
use Backend\Controllers\Index\DashboardHandler;
use BackendMenu;
use October\Rain\Support\Facades\Schema;
use Swordbros\Booking\models\EventCategoryModel;
use Swordbros\Booking\Models\EventModel;
use Swordbros\Booking\models\EventTypeModel;
use Swordbros\Booking\models\EventZoneModel;
use Swordbros\Booking\Models\Message;

class Amele extends Controller
{
    public static function test(){
        echo 'Test Language: '.__('Test Language');
    }
    public static function services(){
        $result = [];
        foreach (EventTypeModel::all() as $item) {
            $result[$item->id] = $item;
        }
        return $result;
    }
    public static function places(){
        $result = [];
        foreach (EventZoneModel::all() as $item) {
            $result[$item->id] = $item;
        }
        return $result;
    }
    public static function subscriptions(){
        return [
             'S1',
            'S2',
            'S3',
        ];
    }
    public static function defaultTab(){
        return "asasas";
    }
    public function dummyData(){
       foreach (Amele::eventTypes() as $code=>$name){
            $item = new EventTypeModel();
            $item->name = $name;
            $item->description = $name.' Description';
            $item->save();
        }
        foreach (Amele::eventZones() as $code=>$name){
            $item = new EventZoneModel();
            $item->name = $name;
            $item->description = $name.' Description';
            $item->save();
        }
        foreach (Amele::eventCategories() as $code=>$name){
            $item = new EventCategoryModel();
            $item->name = $name;
            $item->description = $name.' Description';
            $item->save();
        }
        $item = new EventModel();
        $item->event_zone_id = 1;
        $item->event_category_id = 1;
        $item->event_type_id = 1;
        $item->save();

    }
    public static function eventTypes(){
        return [
            'concert' =>  __('Concerts'),
            'theater' => __('Theater'),
            'cinema' =>  __('Cinema'),
            'workshop' => __('Workshop'),
            'exhibition' => __('Exhibition'),
        ];
    }
    public static function eventZones(){
        return [
            'zone001' =>  __('Küçük Sahne'),
            'zone002' => __('Büyük Sahne'),
            'zone003' =>  __('Atolye'),
        ];
    }
    public static function eventCategories(){
        return [
            'caz' =>  __('Caz'),
            'drama' => __('Drama'),
            'action' =>  __('Aksiyon'),
        ];
    }


}

class Service{
    public $code ;
    public $title ;
    public $icon ;
    public $url ;
    public static function create($code, $title='', $icon='', $url=''){
        $service = new Service();
        $service->code = $code;
        $service->title = $title;
        $service->icon = $icon;
        $service->url = $url;
        return $service;
    }
}
class Place{
    public $code ;
    public $title ;
    public $icon ;
    public $url ;
    public static function create($code, $title='', $icon='', $url=''){
        $service = new Place();
        $service->code = $code;
        $service->title = $title;
        $service->icon = $icon;
        $service->url = $url;
        return $service;
    }
}
