<?php
namespace Swordbros\Booking\controllers;

use ApplicationException;
use Backend\Classes\Controller;
use File;
use Request;
use Swordbros\Booking\Models\EventModel;

class Event extends Controller{
    public $implement = [
        \Backend\Behaviors\FormController::class,
        \Backend\Behaviors\ListController::class
    ];

    public $formConfig = '';

    public $listConfig = 'config_list.yaml';

    public $requiredPermissions = ['admins.manage'];

    public $bodyClass = 'compact-container';

    public $settingsItemCode = 'administrators';

    public function __construct($formType=null)
    {
        if(empty($formType)){
            $formType = \Input::get('type');
            if(empty($formType)){
                $formType = 'default';
            }
        }
        if($formType){
            if (!File::exists(plugins_path('swordbros/booking/controllers/event/config_form_'.$formType.'.yaml'))) {
                throw new ApplicationException('The configuration file config_form_'.$formType.'.yaml does not exist.');
            }
            $this->formConfig = 'config_form_'.$formType.'.yaml';
        }
        parent::__construct();
        $this->pageTitle = __('Events');
    }

    public function createcinema(){
        dd("");
    }
    public function ajaxForm(){

        return $this->emptyForm();
    }
    private function emptyForm(){
        $this->layout = 'empty';
        $model = new EventModel();
        //$this->formWidget->config->tabs['defaultTab'] = 'Modifiye;';
        $this->asExtension('FormController')->initForm($model);

        $this->vars['content'] = $this->makePartial('blank_form');
    }
    public function formRender($options = [])
    {
        return $this->asExtension('FormController')->formRender($options);
    }

}
