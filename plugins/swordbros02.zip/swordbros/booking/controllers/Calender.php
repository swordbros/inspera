<?php
namespace Swordbros\Booking\controllers;


use BackendMenu;
use Flash;
use Input;
use ValidationException;
use Validator;
class Calender extends \Backend\Classes\Controller{


    public $implement = [
        \Backend\Behaviors\FormController::class,
        \Backend\Behaviors\ListController::class
    ];

    public $formConfig = 'config_form.yaml';

    public $listConfig = 'config_list.yaml';

    public $requiredPermissions = ['admins.manage'];

    public $bodyClass = 'compact-container';
    /***/
    public $requiredCss = [
        '/plugins/swordbros/booking/assets/css/swordbros.booking.main.css',
    ];
    public $requiredJs = [
        '/plugins/swordbros/booking/assets/js/swordbros.booking.main.js',
        '/plugins/swordbros/booking/assets/fullcalendar/index.global.js'
    ];
    public function __construct()
    {
        parent::__construct();
        BackendMenu::setContext('swordbros.booking', 'booking');
    }
    public function index(){
        $this->vars['services'] = Amele::services();
        $this->vars['places'] = Amele::places();
        /*$event = new Event();
        $this->vars['initialState'] = '';
        $this->vars['customLogo'] = '';
        $event->ajaxForm();
        $this->vars['form'] = $event->vars['content'];*/
    }

    private function loadAssets(){
        foreach($this->requiredJs as $requiredJs){
            $this->addJs($requiredJs);
        }
        foreach($this->requiredCss as $requiredCss){
            $this->addCss($requiredCss);
        }
    }
    public function beforeDisplay()
    {
        $this->loadAssets();
    }
    public function onDoSomething()
    {
        $service = Input::get('service');
        $place = Input::get('place');

        $event = new Event($service);
        $event->ajaxForm();

        return ['#listBulkActions' => $event->vars['content']];
    }
    protected function showFlashMessage(string $message): void
    {
        Flash::info($message);
    }
    public function onSubmit()
    {
/*        // AJAX ile gönderilen form verilerini al
        $data = post();

        // Validasyon kuralları
        $rules = [
            'name' => 'required|min:3',
            'email' => 'required|email'
        ];

        // Verileri doğrula
        $validation = Validator::make($data, $rules);

        if ($validation->fails()) {
            throw new ValidationException($validation);
        }
*/
        // Başarılı olursa yapılacak işlemler
        return ['success' => true, 'message' => 'Form successfully submitted'];
    }
}
