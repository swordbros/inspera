<div class="layout">
    <div class="layout-row">
        <h1>My Custom Backend Page</h1>
        <p>This is a custom backend page with custom CSS and JS.</p>

        <div class="modal fade" id="myModal" tabindex="-1" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">
                            Yeni Etkinlik
                        </h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                            <form data-request="onDoSomething"  class="row" data-request-success="successHandler()">
                                <div class="col-md-6">

                                    <h6>Etkinlik türü Seçiniz</h6>
                                    <ul class="list-unstyled">
                                        <?php $checked = 'checked'; ?>
                                        <?php foreach($services as $service){ ?>
                                            <li><label><input type="radio" name="service" <?=$checked?> value="<?=$service->code?>"> <?=$service->name?></label></li>
                                            <?php $checked = ''; ?>
                                        <?php } ?>
                                    </ul>
                                </div>
                                <div class="col-md-6">
                                    <h6>Etkinlik yeri Seçiniz</h6>
                                    <ul class="list-unstyled">
                                        <?php $checked = 'checked'; ?>
                                        <?php foreach($places as $place){ ?>
                                            <li><label><input type="radio" name="place" <?=$checked?> value="<?=$place->id?>"> <?=$place->name?></label></li>
                                            <?php $checked = ''; ?>
                                        <?php } ?>
                                    </ul>
                                </div>
                                <div class="col-md-12">
                                    <button class="btn btn-primary" type="submit">Devam</button>

                                </div>
                                <input type="hidden" name="date" value="" id="date">
                            </form>
                        <div class="row">
                            <div class="col-md-12 mt-2" id="listBulkActions"></div>
                        </div>
                    </div>
                    <div class="modal-footer text-end">


                    </div>
                </div>
            </div>
        </div>
        <div id="calendar"></div>
    </div>

    <script>

        document.addEventListener('DOMContentLoaded', function() {
            var calendarEl = document.getElementById('calendar');

            var calendar = new FullCalendar.Calendar(calendarEl, {
                headerToolbar: {
                    left: 'prev,next today',
                    center: 'title',
                    right: 'dayGridMonth,timeGridWeek,timeGridDay'
                },
                initialDate: '2024-06-12',
                navLinks: true, // can click day/week names to navigate views
                selectable: true,
                selectMirror: true,
                select: function(arg) {
                    /*var title = prompt('Event Title:');
                    if (title) {
                        calendar.addEvent({
                            title: title,
                            start: arg.start,
                            end: arg.end,
                            allDay: arg.allDay
                        })
                    }
                    calendar.unselect();*/
                    console.log(arg);
                    $('#date').val(arg.startStr);
                    var myModal = new bootstrap.Modal(document.getElementById('myModal'), {
                        keyboard: false
                    });
                    $('#listBulkActions').html('');
                    myModal.show();
                },
                eventClick: function(arg) {
                    if (confirm('Are you sure you want to delete this event?')) {
                        arg.event.remove()
                    }
                },
                editable: true,
                dayMaxEvents: true, // allow "more" link when too many events
                events: [
                    {
                        title: 'All Day Event',
                        start: '2024-06-01'
                    },
                    {
                        title: 'Sahne 1 / Zülfü Livaneli',
                        start: '2024-06-07T03:14:00',
                        end: '2024-06-07T16:17:00'
                    },
                    {
                        title: 'Sergi Salonu / Modern Sanat',
                        start: '2024-06-07T03:14:00',
                        end: '2024-06-07T16:17:00'
                    },
                    {
                        groupId: 999,
                        title: 'Cem Yılmaz',
                        start: '2024-06-09T03:18:00'
                    },
                    {
                        groupId: 999,
                        title: 'Cem Yılmaz',
                        start: '2024-06-10T00:18:00',
                        end: '2024-06-10T00:20:00'
                    },

                ],
                eventDidMount: function(info) {

                }
            });

            calendar.render();
        });

    </script>

    <script>
               function successHandler(data) {
                   $('[data-richeditor-textarea]').each(function () {
                       console.log(this);
                       $(this).richEditor();
                   });
               }
//
//
//        function errorHandler(data) {
//            // Hata mesajlarını işleme
//            var messages = '';
//            for (var field in data.responseJSON.errors) {
//                messages += data.responseJSON.errors[field].join('\n') + '\n';
//            }
//            alert(messages);
//        }
//
    </script>
</div>
