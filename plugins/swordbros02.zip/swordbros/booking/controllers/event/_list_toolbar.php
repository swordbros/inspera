<div data-control="toolbar">
    <?php if (BackendAuth::userHasAccess('admins.manage.create')): ?>
        <a href="<?= Backend::url('swordbros/booking/event/create') ?>" class="btn btn-primary oc-icon-plus">
            Yeni Etkinlik
        </a>
    <?php endif ?>
</div>
