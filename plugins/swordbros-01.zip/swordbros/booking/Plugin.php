<?php namespace Swordbros\Booking;

use System\Classes\PluginBase;

class Plugin extends PluginBase
{
    public function pluginDetails()
    {
        return [
            'name'        => 'Swordbros Plugins',
            'description' => 'Booking Content',
            'author'      => 'Swordbros',
            'icon'        => 'icon-leaf'
        ];
    }

    public function registerNavigation()
    {
        return [
            'booking' => [
                'label'       => 'Booking',
                'url'         => \Backend::url('swordbros/booking/calender'),
                'icon'        => 'icon-smile-o',
                'permissions' => ['swordbros.booking.*'],
                'order' => 500,

            ],
        ];
    }
    public function registerComponents()
    {

        return [
            \Swordbros\Booking\components\Content::class => 'swordbrosBooking',
        ];
    }
}
