<?php namespace Swordbros\Booking\Models;

use Backend\Models\UserGroup;
use Backend\Models\UserRole;
use Model;
use Swordbros\Booking\Controllers\Helper;

class Theater extends Model
{
    protected $table = 'swordbros_booking_theaters';
    public $attachOne = [
        'avatar' => \System\Models\File::class
    ];


    public function getRoleOptions()
    {
        $result = [];

        foreach (UserRole::all() as $role) {
            $result[$role->id] = [$role->name, $role->description];
        }

        return $result;
    }
    public function getSubscriptionOptions(){
        return Helper::subscriptions();
    }
}
