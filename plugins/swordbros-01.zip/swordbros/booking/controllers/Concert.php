<?php
namespace Swordbros\Booking\Controllers;


use BackendMenu;

class Concert extends \Backend\Classes\Controller
{
    public $implement = [
        \Backend\Behaviors\ListController::class
    ];

    public $listConfig = 'config_list.yaml';


}
