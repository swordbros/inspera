<?php
namespace Swordbros\Booking\Controllers;


use BackendMenu;

class Calender extends \Backend\Classes\Controller
{
    public $implement = [
        \Backend\Behaviors\ListController::class
    ];

    public $listConfig = 'config_list.yaml';


}
