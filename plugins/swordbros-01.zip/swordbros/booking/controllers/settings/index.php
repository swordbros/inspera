<!-- Primary content -->
<?php Block::put('form-contents') ?>
<h1><?=$title?></h1>
<ul>
    <?php foreach($services as $service){ ?>
        <li><a href="<?=$service['url']?>"><?=$service['title']?></a></li>
    <?php } ?>
</ul>
<?php Block::endPut() ?>
<!-- Complimentary sidebar -->
<?php Block::put('form-sidebar') ?>
Side Bar content
<?php Block::endPut() ?>
<!-- Layout execution -->
<?php Block::put('body') ?>
<?= $this->makeLayout('form-with-sidebar') ?>
<?php Block::endPut() ?>
