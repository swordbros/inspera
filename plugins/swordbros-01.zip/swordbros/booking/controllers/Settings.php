<?php namespace Swordbros\Booking\Controllers;

use Backend\Classes\SettingsController;
use BackendMenu;
use October\Rain\Support\Facades\Schema;


class Settings extends SettingsController
{
    public function __construct()
    {
        parent::__construct();
        BackendMenu::setContext('Swordbros.Booking', 'booking');
    }

    public function index()
    {
        $this->pageTitle = 'Booking World';
        $this->bodyClass = 'compact-container';
        $this->vars['title'] = 'Booking Settings';
        $this->vars['services'] = Helper::services();
    }

    public function database()
    {
        $this->pageTitle = 'Database|Booking World';
        if(Schema::hasTable('swordbros_booking_messages')){
            return ;
        }
        Schema::create('swordbros_booking_messages', function($table) {
            $table->increments('id');
            $table->string('message');
            $table->timestamps();
        });
    }
}
