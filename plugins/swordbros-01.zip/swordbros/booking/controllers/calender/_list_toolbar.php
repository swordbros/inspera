<div data-control="toolbar">
    <?php if (BackendAuth::userHasAccess('admins.manage.create')): ?>
        <a href="<?= Backend::url('swordbros/booking/theater/create') ?>" class="btn btn-primary oc-icon-plus">
            Yeni Tiyatro
        </a>
    <?php endif ?>
</div>
