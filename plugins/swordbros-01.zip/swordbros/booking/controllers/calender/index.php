<?= $this->makeLayoutPartial('sidenav') ?>
<?= $this->listRender() ?>
