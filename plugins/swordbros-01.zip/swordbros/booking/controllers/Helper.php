<?php namespace Swordbros\Booking\Controllers;

use Backend\Classes\Controller;
use Backend\Controllers\Index\DashboardHandler;
use BackendMenu;
use October\Rain\Support\Facades\Schema;
use Swordbros\Booking\Models\Message;

class Helper extends Controller
{
    public static function test(){
        echo 'Test Language: '.__('Test Language');
    }
    public static function services(){
        return [
            'concert'=>[
                'code'=>'concert',
                'title'=> __('Concerts'),
                'icon'=> 'icon-smile-o',
                'url'=> \Backend::url('swordbros/booking/concert'),
            ],
            'theater'=>[
                'code'=>'theater',
                'title'=> __('Theaters'),
                'icon'=> 'icon-smile-o',
                'url'=> \Backend::url('swordbros/booking/theater'),
            ],
            'cinema'=>[
                'code'=>'cinema',
                'title'=> __('Cinemas'),
                'icon'=> 'icon-smile-o',
                'url'=> \Backend::url('swordbros/booking/cinema'),
            ],
            'restaurant'=>[
                'code'=>'restaurant',
                'title'=> __('Restaurant'),
                'icon'=> 'icon-smile-o',
                'url'=> \Backend::url('swordbros/booking/restaurant'),
            ],
            'showroom'=>[
                'code'=>'showroom',
                'title'=> __('Showroom'),
                'icon'=> 'icon-smile-o',
                'url'=> \Backend::url('swordbros/booking/showroom'),
            ]
        ];
    }
    public static function subscriptions(){
        return [
             'S1',
            'S2',
            'S3',
        ];
    }
}
