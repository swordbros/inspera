<?php namespace Swordbros\Booking\components;

use System;
use Backend;
use Cms\Classes\ComponentBase;

/**
 * BackendLink component
 */
class Content extends ComponentBase
{
    public function componentDetails()
    {
        return [
            'name' => 'Booking Content',
            'description' => 'Makes the backend area link available.'
        ];
    }

    public function onRun()
    {
        $this->page['items'] = ['I love Swordbros'];
    }
}
